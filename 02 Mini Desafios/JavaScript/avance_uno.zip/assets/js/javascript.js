var a = +prompt('ingrese un valor distinto a cero')
var b = +prompt('ingrese un segundo valor distinto a cero')

let suma = a + b
alert('El valor de la suma es:' + suma)

let resta = a - b
alert('El valor de la resta es:' + resta)

let multi = a * b
alert('El valor de la multiplicación es:' + multi)

let division = a / b
alert('El valor de la división es:' + division)


let modulo = a % b
alert('El valor del modulo es:' + modulo)



