<script>
$(function () {
    $('[data-toggle="popover"]').popover()
  })

  $(function () {
$('.example-popover').popover({
container: 'body'
})
})


</script>