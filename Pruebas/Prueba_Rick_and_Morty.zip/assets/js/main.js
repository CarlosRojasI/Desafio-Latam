// Punto 3 archivo main e importacion de
import DetallesPersonajes from './detallesPersonajes.js'

const llamadoPersonajes = (() => {
    const urlPrincipal = "https://rickandmortyapi.com/api/character/";
    let domPersonajes = $(".resultados");
    let almacenApi = null;

    // primera funsion asincrona privada
    const getConeccionUrl = async () => {
        try {
            const respuestaApi = await fetch(urlPrincipal);
            almacenApi = await respuestaApi.json();
            return almacenApi;
        } catch (error) {
            console.log(error);
        } finally {}
    }

    // segunda funsion asincrona privada
    const getLocacion = async (id) => {
        try {
            const arrayPersonajes = await fetch(`${urlPrincipal}${id}`)
            const array = arrayPersonajes.json();
            return new DetallesPersonajes(id, array.name, array.status, array.species, array.gender, array.created, array.origin, array.location, array.episode.length, array.image)
        } catch (error) {
            console.log(error)
            return null;
        } finally {
            $(".spinner").addClass("d-none");
        }
    }
    return {
        getPersonajes: async () => {
            const inicio = await getConeccionUrl()
            inicio.results.forEach(async (e) => {
                const lista = await getLocacion(e.id)
                domPersonajes.append(`
            <div class="col-md-3" data-toggle="modal" data-target="#exampleModal${
                    e.id
                }">
                <img src="${
                    e.image
                }" alt="">
                <span>${
                    e.id
                }</span>
                <span>${
                    e.species
                }</span>
            </div>
             <!-- Modal -->
             <div class="modal fade" id="exampleModal${
                    e.id
                }" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detalle de Personajes</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                  <p>id: ${
                    e.id
                }</p>
                  <p>Nombre: ${
                    e.name
                }</p>
                  <p>Especie:${
                    e.species
                }</p>
                  <p>Gender: ${
                    e.gender
                }</p>
                  <p>creado: ${
                    e.created
                }</p>
                  <p>Origen: ${
                    e.origin.name
                }</p>
                  <p>Ubicación: ${
                    e.location.name
                }</p>
                  <p>Total episodios: ${
                    e.episode.length
                }</p>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
            `)
            })
        }
    }
})()

llamadoPersonajes.getPersonajes()
