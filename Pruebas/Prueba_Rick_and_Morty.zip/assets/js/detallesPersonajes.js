import Personajes from './personajes.js'

class DetallesPersonajes extends Personajes {
  constructor(
    id,
    name,
    status,
    species,
    gender,
    created,
    origin,
    location,
    episode,
    image
  ) {
    super(id);
    let _name = name;
    this.getName = () => _name;
    this.setName = (nuevoNombre) => {
      _name = nuevoNombre;
    };

    let _status = status;
    this.getStatus = () => _status;
    this.setStatus = (nuevoEstado) => {
      _status = nuevoEstado;
    };

    let _image = image;
    this.getimage = () => _image;
    this.setimage = (nuevoEstado) => {
      _image = nuevoEstado;
    };

    this._id = id;
    this._species = species;
    this._gender = gender;
    this._created = created;
    this._origin = origin;
    this._location = location;
    this._episode = episode;
  }

  get name() {
    return this.getName();
  }

  setName(nuevoName) {
    this.setName(nuevoName);
  }

  get status() {
    return this.getStatus();
  }

  setStatus(getStatus) {
    this.setStatus = setStatus;
  }

  getimage() {
    return this.getimage();
  }

  setimage(getimage) {
    this.setimage = setimage;
  }

  infoModal(){

  }


}

export default DetallesPersonajes;
