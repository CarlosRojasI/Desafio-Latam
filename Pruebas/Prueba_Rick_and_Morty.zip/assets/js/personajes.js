class Personajes {
  constructor(id) {
    let _id = id;
    this.getid = () => _id;
    this.setid = (nuevoId) => {
      _id = nuevoId;
    };
  }
  getidPersonajes() {
    return this.getid();
  }

  setidPersonajes(nuevoId) {
    this.setid(nuevoId);
  }
}

export default Personajes;
