
// const personas = [
//     { id: 1, nombre: 'Constanza', edad: 24},
//     { id: 2, nombre: 'Carlos', edad: 42},
//     { id: 3, nombre: 'Alicia', edad: 36},
    
// ];

// const cuerpo = document.getElementById("cuerpo")
// console.log(cuerpo)
// for(persona of personas){
//     cuerpo.innerHTML += `
//     <tr>
//         <td>${persona.id}</td>
//         <td>${persona.nombre}</td>
//         <td>${persona.edad}</td>
//     </tr>
//     `
// }


//  con Jquery

const personas = [
    { id: 1, nombre: 'Constanza', edad: 24},
    { id: 2, nombre: 'Carlos', edad: 42},
    { id: 3, nombre: 'Alicia', edad: 36},
];


for(persona of personas){
    $("#cuerpo").append(`
    <tr>
        <td>${persona.id}</td>
        <td>${persona.nombre}</td>
        <td>${persona.edad}</td>
    </tr>
    `)
}

