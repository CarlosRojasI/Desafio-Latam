const consultaDental = [
    {
        HORA: "8:30",
        ESPECIALISTA: "ANDREA ZUÑIGA",
        PACIENTE: "MARCELA RETAMAL",
        RUT: "11123425-6",
        PREVISION: "ISAPRE"
    },
    {
        HORA: "11:00",
        ESPECIALISTA: "MARIA PIA ZAÑARTU",
        PACIENTE: "ANGEL MUÑOZ",
        RUT: "9878789-2",
        PREVISION: "ISAPRE"
    },
    {
        HORA: "11:30",
        ESPECIALISTA: "SCARLETT WITTING",
        PACIENTE: "MARIO KAST",
        RUT: "7998789-5",
        PREVISION: "FONASA"
    },
    {
        HORA: "13:00",
        ESPECIALISTA: "FRANCISCO VON TEUBER",
        PACIENTE: "KARIN FERNANDEZ",
        RUT: "18887662-K",
        PREVISION: "FONASA"
    }, {
        HORA: "13:30",
        ESPECIALISTA: "EDUARDO VIÑUELA",
        PACIENTE: "HUGO SANCHEZ",
        RUT: "17665461-4",
        PREVISION: "FONASA"
    }, {
        HORA: "14:00",
        ESPECIALISTA: "RAQUEL VILLASECA",
        PACIENTE: "ANA SEPULVEDA",
        RUT: "14441281-0",
        PREVISION: "ISAPRE"
    },
];

// let ordenConsulta = consultaDental.sort((a,b) => a.hora - b.hora);

// for (consulta of consultaDental) {
//     $("#cuerpo").append(`
//         <tr>
//             <td>${consulta.HORA}</td>
//             <td>${consulta.ESPECIALISTA}</td>
//             <td>${consulta.PACIENTE}</td>
//             <td>${consulta.RUT}</td>
//             <td>${consulta.PREVISION}</td>
//         </tr>
//         `);
// }

const cuerpo = document.getElementById("cuerpo")

for(consulta of consultaDental){
    cuerpo.innerHTML += `
    <tr>
        <td>${consulta.HORA}</td>
        <td>${consulta.ESPECIALISTA}</td>
        <td>${consulta.PACIENTE}</td>
        <td>${consulta.RUT}</td>
        <td>${consulta.PREVISION}</td>

    </tr>
    `
}


/////  Segundo caso

var primeraCita = consultaDental[0].PACIENTE
var ultimaCita = consultaDental[consulta.length-1].PACIENTE
document.write(primeraCita)
document.write(ultimaCita[0])
